package org.robotframework.swing.testapp;

import java.awt.Component;

public interface Operation {
    void perform(Component operatedComponent);
}
