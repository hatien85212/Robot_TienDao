package org.robotframework.swing.testapp;

import javax.swing.JLabel;

public class TestLabel extends JLabel {
    public TestLabel() {
        super("Test Label");
        setName("testLabel");
        setToolTipText("TEST LABEL");
    }
}
